package puppet;

public class PuppetConstants {
	public static final String NODES_FOLDER="/etc/puppet/manifests/";
}
